package biz

// Mirror only the fields you need:
type KeyInfo struct {
	KMSProviderUUID string
	KeyType         int32
	KeyName         string
}
type TfDenom int32

type Header struct {
	UUID    string
	AppName string
}
type KeyAttributes struct {
	KeyType int32
	KeyName string
}

type UserId string
