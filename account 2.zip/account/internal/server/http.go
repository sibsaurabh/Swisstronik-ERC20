package server

import (
	v1 "account/api/account/v1"
	"account/internal/conf"
	"account/internal/service"

	"github.com/MicahParks/keyfunc/v3"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware/auth/jwt"
	"github.com/go-kratos/kratos/v2/middleware/logging"
	"github.com/go-kratos/kratos/v2/middleware/metrics"
	"github.com/go-kratos/kratos/v2/middleware/recovery"
	"github.com/go-kratos/kratos/v2/middleware/tracing"
	"github.com/go-kratos/kratos/v2/transport/http"
	jwtv5 "github.com/golang-jwt/jwt/v5"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

// NewHTTPServer creates an HTTP server with recovery, logging, and tracing middleware.
func NewHTTPServer(
	c *conf.Server,
	account *service.AccountService,
	logger log.Logger,
	jwks keyfunc.Keyfunc,
) *http.Server {
	// Base options: middleware chain
	opts := []http.ServerOption{
		http.Middleware(
			recovery.Recovery(),    // panic recovery
			logging.Server(logger), // structured logging
			tracing.Server(),       // distributed tracing
			metrics.Server(),
			jwt.Server(func(token *jwtv5.Token) (interface{}, error) {
				return jwks.Keyfunc(token)
			}, jwt.WithSigningMethod(jwtv5.SigningMethodES256)),
		),
	}

	// Conditionally add network, address, timeout
	if c.Http.Network != "" {
		opts = append(opts, http.Network(c.Http.Network))
	}
	if c.Http.Addr != "" {
		opts = append(opts, http.Address(c.Http.Addr))
	}
	if c.Http.Timeout != nil {
		opts = append(opts, http.Timeout(c.Http.Timeout.AsDuration()))
	}

	srv := http.NewServer(opts...)
	v1.RegisterAccountHTTPServer(srv, account)
	srv.Handle("/metrics", promhttp.Handler())
	return srv
}
