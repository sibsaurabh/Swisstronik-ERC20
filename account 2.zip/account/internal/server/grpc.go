package server

import (
	v1 "account/api/account/v1"
	"account/internal/conf"
	"account/internal/service"

	"github.com/MicahParks/keyfunc/v3"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware/auth/jwt"
	"github.com/go-kratos/kratos/v2/middleware/logging"
	"github.com/go-kratos/kratos/v2/middleware/metrics"
	"github.com/go-kratos/kratos/v2/middleware/recovery"
	"github.com/go-kratos/kratos/v2/middleware/tracing"
	"github.com/go-kratos/kratos/v2/transport/grpc"
	jwtv5 "github.com/golang-jwt/jwt/v5"
)

// NewGRPCServer creates a gRPC server with recovery, logging, and tracing middleware.
func NewGRPCServer(
	c *conf.Server,
	account *service.AccountService,
	logger log.Logger,
	jwks keyfunc.Keyfunc,
) *grpc.Server {
	// Base options: middleware chain
	opts := []grpc.ServerOption{
		grpc.Middleware(
			recovery.Recovery(),    // panic recovery
			logging.Server(logger), // structured logging
			tracing.Server(),       // distributed tracing
			metrics.Server(),
			jwt.Server(func(token *jwtv5.Token) (interface{}, error) {
				return jwks.Keyfunc(token)
			}, jwt.WithSigningMethod(jwtv5.SigningMethodES256)),
		),
	}

	// Conditionally add network, address, timeout
	if c.Grpc.Network != "" {
		opts = append(opts, grpc.Network(c.Grpc.Network))
	}
	if c.Grpc.Addr != "" {
		opts = append(opts, grpc.Address(c.Grpc.Addr))
	}
	if c.Grpc.Timeout != nil {
		opts = append(opts, grpc.Timeout(c.Grpc.Timeout.AsDuration()))
	}

	srv := grpc.NewServer(opts...)
	v1.RegisterAccountServer(srv, account)
	return srv
}
