//go:build wireinject
// +build wireinject

package main

import (
	"account/internal/biz"
	"account/internal/conf"
	"account/internal/data"
	"account/internal/server"
	"account/internal/service"
	"context"
	"time"

	blk "account/api/blkchn-svc/v1"
	blockchain "account/api/blockchain"
	kms "account/api/kms-svc/v1"

	"github.com/go-kratos/kratos/v2"
	"github.com/go-kratos/kratos/v2/log"

	// rpc "github.com/go-kratos/kratos/v2/transport/grpc"
	rpc "google.golang.org/grpc"

	"github.com/MicahParks/keyfunc/v3"
	"github.com/google/wire"
	"google.golang.org/grpc/credentials/insecure"
)

// NewJWKS creates the jwks using the well-known endpoint and returns cleanup to stop refresh.
func NewJWKS(c *conf.Server) (keyfunc.Keyfunc, func(), error) {
	// create a cancelable context so we can stop the background refresh
	ctx, cancel := context.WithCancel(context.Background())

	override := keyfunc.Override{
		RefreshInterval: 2 * time.Minute,
	}

	// Use NewDefaultCtx so keyfunc starts the refresh goroutine using the provided ctx
	jwks, err := keyfunc.NewDefaultOverrideCtx(ctx, []string{c.JwksUrl}, override)
	if err != nil {
		// return error (don't log.Fatalf here — let caller handle it)
		cancel()
		return nil, nil, err
	}

	// cleanup stops the refresh goroutine by cancelling the context
	cleanup := func() {
		cancel()
	}

	return jwks, cleanup, nil
}

// NewBlockchainClient dials the downstream blockchain and returns its client and cleanup.
func NewBlockchainClient(c *conf.Server) (blockchain.BlockchainServiceClient, func(), error) {
	conn, err := rpc.Dial(
		c.Downstream.Blockchain,
		rpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		return nil, nil, err
	}
	cleanup := func() { conn.Close() }
	return blockchain.NewBlockchainServiceClient(conn), cleanup, nil
}

// NewBlkClient dials the downstream blkchn-svc and returns its client and cleanup.
func NewBlkClient(c *conf.Server) (blk.BlkchnSvcClient, func(), error) {
	conn, err := rpc.Dial(
		c.Downstream.Blkchn,
		rpc.WithTransportCredentials(insecure.NewCredentials()),
	)

	if err != nil {
		log.Errorf("Failed to connect to blkchn-svc: %v", err)
		return nil, nil, err
	}

	cleanup := func() {
		log.Infof("Closing blkchn-svc connection")
		conn.Close()
	}
	return blk.NewBlkchnSvcClient(conn), cleanup, nil
}

// NewKmsClient dials the downstream kms-svc and returns its client and cleanup.
func NewKmsClient(c *conf.Server) (kms.KmsSvcClient, func(), error) {
	conn, err := rpc.Dial(
		c.Downstream.Kms,
		rpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		return nil, nil, err
	}
	cleanup := func() { conn.Close() }
	return kms.NewKmsSvcClient(conn), cleanup, nil
}

// wireApp initializes the Kratos application with all dependencies.
func wireApp(
	c *conf.Server,
	d *conf.Data,
	logger log.Logger,
) (*kratos.App, func(), error) {
	panic(wire.Build(
		NewJWKS,
		NewBlockchainClient,
		NewBlkClient,
		NewKmsClient,
		data.ProviderSet,
		biz.ProviderSet,
		service.ProviderSet,
		server.ProviderSet,
		newApp,
	))
}
