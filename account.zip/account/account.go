package service

import (
	"context"

	pb "account/api/account/v1"
)

type AccountService struct {
	pb.UnimplementedAccountServer
}

func NewAccountService() *AccountService {
	return &AccountService{}
}

func (s *AccountService) GetAddr(ctx context.Context, req *pb.GetAddrRequest) (*pb.GetAddrResponse, error) {
	return &pb.GetAddrResponse{}, nil
}
func (s *AccountService) GetBalance(ctx context.Context, req *pb.GetBalanceRequest) (*pb.GetBalanceResponse, error) {
	return &pb.GetBalanceResponse{}, nil
}
func (s *AccountService) Send(ctx context.Context, req *pb.SendRequest) (*pb.SendResponse, error) {
	return &pb.SendResponse{}, nil
}
func (s *AccountService) GenKey(ctx context.Context, req *pb.GenKeyRequest) (*pb.GenKeyResponse, error) {
	return &pb.GenKeyResponse{}, nil
}
func (s *AccountService) GetPubKey(ctx context.Context, req *pb.GetPubKeyRequest) (*pb.GetPubKeyResponse, error) {
	return &pb.GetPubKeyResponse{}, nil
}
