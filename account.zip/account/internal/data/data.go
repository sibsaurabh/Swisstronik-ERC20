// package data

// import (
// 	biz "account/internal/biz"
// 	"account/internal/conf"

// 	"github.com/go-kratos/kratos/v2/log"
// 	"github.com/google/wire"
// )

// // ProviderSet is data providers.
// var ProviderSet = wire.NewSet(
// 	NewAccountRepo,
// 	wire.Bind(new(biz.AccountRepo), new(*accountRepo)),
// )

// // Data .
// type Data struct {
// 	// TODO wrapped database client
// }

// // NewData .
//
//	func NewData(c *conf.Data, logger log.Logger) (*Data, func(), error) {
//		cleanup := func() {
//			log.NewHelper(logger).Info("closing the data resources")
//		}
//		return &Data{}, cleanup, nil
//	}
package data

import (
	"github.com/google/wire"
)

var ProviderSet = wire.NewSet(
	NewAccountRepo,
	// wire.Bind(new(biz.AccountRepo), new(*accountRepo)),
)
