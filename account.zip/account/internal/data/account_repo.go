package data

import (
	"context"

	blk "account/api/blkchn-svc/v1"
	kms "account/api/kms-svc/v1"
	biz "account/internal/biz"

	"github.com/go-kratos/kratos/v2/log"
)

// accountRepo implements biz.AccountRepo by proxying to two downstream gRPC services.
type accountRepo struct {
	blkClient blk.BlkchnSvcClient
	kmsClient kms.KmsSvcClient
	logger    *log.Helper
}

// NewAccountRepo creates a new biz.AccountRepo using the given downstream clients.
func NewAccountRepo(
	blkClient blk.BlkchnSvcClient,
	kmsClient kms.KmsSvcClient,
	logger log.Logger,
) biz.AccountRepo {
	return &accountRepo{
		blkClient: blkClient,
		kmsClient: kmsClient,
		logger:    log.NewHelper(logger),
	}
}

// GetAddress calls the blkchn-svc GetAddr RPC.
func (r *accountRepo) GetAddress(ctx context.Context, ki biz.KeyInfo) (string, error) {
	resp, err := r.blkClient.GetAddr(ctx, &blk.GetAddrRequest{
		KeyInfo: &blk.KeyInfo{
			KmsProviderUuid: ki.KMSProviderUUID,
			KeyType:         blk.KeyType(ki.KeyType),
			KeyName:         ki.KeyName,
		},
	})
	if err != nil {
		r.logger.Errorf("GetAddr error: %v", err)
		return "", err
	}
	return resp.Address, nil
}

// GetBalance calls the blkchn-svc GetBalance RPC.
func (r *accountRepo) GetBalance(ctx context.Context, denom biz.TfDenom, address string) (string, error) {
	resp, err := r.blkClient.GetBalance(ctx, &blk.GetBalanceRequest{
		Denom:   blk.TfDenom(denom),
		Address: address,
	})
	if err != nil {
		r.logger.Errorf("GetBalance error: %v", err)
		return "", err
	}
	return resp.Value, nil
}

// Send calls the blkchn-svc Send RPC and returns the transaction hash.
func (r *accountRepo) Send(ctx context.Context, from biz.KeyInfo, toAddr string, denom biz.TfDenom, val string) (string, error) {
	resp, err := r.blkClient.Send(ctx, &blk.SendRequest{
		FromKeyInfo: &blk.KeyInfo{
			KmsProviderUuid: from.KMSProviderUUID,
			KeyType:         blk.KeyType(from.KeyType),
			KeyName:         from.KeyName,
		},
		ToAddress: toAddr,
		Denom:     blk.TfDenom(denom),
		Value:     val,
	})
	if err != nil {
		r.logger.Errorf("Send error: %v", err)
		return "", err
	}
	return resp.Txhash, nil
}

// GenKey calls the kms-svc GenKey RPC and returns the created key name.
func (r *accountRepo) GenKey(ctx context.Context, header biz.Header, attrs biz.KeyAttributes) (string, error) {
	resp, err := r.kmsClient.GenKey(ctx, &kms.GenKeyRequest{
		Header: &kms.Header{
			Uuid:    header.UUID,
			AppName: header.AppName,
		},
		KeyName:    &attrs.KeyName,
		Attributes: &kms.KeyAttributes{KeyType: kms.KeyType(attrs.KeyType)},
	})
	if err != nil {
		r.logger.Errorf("GenKey error: %v", err)
		return "", err
	}
	return resp.KeyName, nil
}

// GetPubKey calls the kms-svc GetPubKey RPC and returns the public key bytes.
func (r *accountRepo) GetPubKey(ctx context.Context, header biz.Header, attrs biz.KeyAttributes) ([]byte, error) {
	resp, err := r.kmsClient.GetPubKey(ctx, &kms.GetPubKeyRequest{
		Header:     &kms.Header{Uuid: header.UUID, AppName: header.AppName},
		KeyName:    attrs.KeyName,
		Attributes: &kms.KeyAttributes{KeyType: kms.KeyType(attrs.KeyType)},
	})
	if err != nil {
		r.logger.Errorf("GetPubKey error: %v", err)
		return nil, err
	}
	return resp.PubKey, nil
}

// ProviderSet defines data-layer providers and bindings for DI.
// var ProviderSet = wire.NewSet(
// 	NewAccountRepo,
// )
