package service

import (
	"context"

	pb "account/api/account/v1"
	"account/internal/biz"
	// "github.com/google/wire"
)

// AccountService implements the gRPC AccountServiceServer.
type AccountService struct {
	pb.UnimplementedAccountServer
	uc *biz.AccountUsecase
}

// NewAccountService creates a new AccountService with injected business logic.
func NewAccountService(uc *biz.AccountUsecase) *AccountService {
	return &AccountService{uc: uc}
}

// GetAddr handles the GetAddr RPC by delegating to the usecase layer.
func (s *AccountService) GetAddr(ctx context.Context, req *pb.GetAddrRequest) (*pb.GetAddrResponse, error) {
	addr, err := s.uc.GetAddr(ctx, biz.KeyInfo{
		KMSProviderUUID: req.KeyInfo.KmsProviderUuid,
		KeyType:         int32(req.KeyInfo.KeyType),
		KeyName:         req.KeyInfo.KeyName,
	})
	if err != nil {
		return nil, err
	}
	return &pb.GetAddrResponse{Address: addr}, nil
}

// GetBalance handles the GetBalance RPC by delegating to the usecase layer.
func (s *AccountService) GetBalance(ctx context.Context, req *pb.GetBalanceRequest) (*pb.GetBalanceResponse, error) {
	value, err := s.uc.GetBalance(ctx, biz.TfDenom(req.Denom), req.Address)
	if err != nil {
		return nil, err
	}
	return &pb.GetBalanceResponse{
		Denom: req.Denom,
		Value: value,
	}, nil
}

// Send handles the Send RPC by delegating to the usecase layer.
func (s *AccountService) Send(ctx context.Context, req *pb.SendRequest) (*pb.SendResponse, error) {
	txhash, err := s.uc.Send(ctx,
		biz.KeyInfo{
			KMSProviderUUID: req.FromKeyInfo.KmsProviderUuid,
			KeyType:         int32(req.FromKeyInfo.KeyType),
			KeyName:         req.FromKeyInfo.KeyName,
		},
		req.ToAddress,
		biz.TfDenom(req.Denom),
		req.Value,
	)
	if err != nil {
		return nil, err
	}
	return &pb.SendResponse{Txhash: txhash}, nil
}

// GenKey handles the GenKey RPC by delegating to the usecase layer.
func (s *AccountService) GenKey(ctx context.Context, req *pb.GenKeyRequest) (*pb.GenKeyResponse, error) {
	keyName, err := s.uc.GenKey(ctx,
		biz.Header{UUID: req.Header.Uuid, AppName: req.Header.AppName},
		biz.KeyAttributes{KeyType: int32(req.Attributes.KeyType)},
	)
	if err != nil {
		return nil, err
	}
	return &pb.GenKeyResponse{
		Header:     &pb.Header{Uuid: req.Header.Uuid, AppName: req.Header.AppName},
		KeyName:    keyName,
		Attributes: &pb.KeyAttributes{KeyType: req.Attributes.KeyType},
	}, nil
}

// GetPubKey handles the GetPubKey RPC by delegating to the usecase layer.
func (s *AccountService) GetPubKey(ctx context.Context, req *pb.GetPubKeyRequest) (*pb.GetPubKeyResponse, error) {
	pubKey, err := s.uc.GetPubKey(ctx,
		biz.Header{UUID: req.Header.Uuid, AppName: req.Header.AppName},
		biz.KeyAttributes{KeyType: int32(req.Attributes.KeyType)},
	)
	if err != nil {
		return nil, err
	}
	return &pb.GetPubKeyResponse{
		Header:     &pb.Header{Uuid: req.Header.Uuid, AppName: req.Header.AppName},
		KeyName:    req.KeyName,
		Attributes: &pb.KeyAttributes{KeyType: req.Attributes.KeyType},
		PubKey:     pubKey,
	}, nil
}

// ProviderSet is the Wire provider set for service layer.
// var ProviderSet = wire.NewSet(NewAccountService)
