package biz

import "context"

type AccountRepo interface {
	GetAddress(ctx context.Context, ki KeyInfo) (string, error)
	GetBalance(ctx context.Context, denom TfDenom, address string) (string, error)
	Send(ctx context.Context, from KeyInfo, toAddr string, denom TfDenom, val string) (string, error)
	GenKey(ctx context.Context, h Header, a KeyAttributes) (string, error)
	GetPubKey(ctx context.Context, h Header, a KeyAttributes) ([]byte, error)
}
