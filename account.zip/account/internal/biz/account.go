package biz

import "context"

// AccountUsecase handles business logic for account operations.
type AccountUsecase struct {
	repo AccountRepo
}

// NewAccountUsecase creates a new AccountUsecase with the given repository.
func NewAccountUsecase(r AccountRepo) *AccountUsecase {
	return &AccountUsecase{repo: r}
}

// CreateKey proxies the CreateKey call to the repository.
func (uc *AccountUsecase) CreateKey(ctx context.Context, ui UserId) (string, error) {
	return uc.repo.CreateKey(ctx, ui)
}

// GetAddr proxies the GetAddress call to the repository.
func (uc *AccountUsecase) GetAddr(ctx context.Context, ki KeyInfo) (string, error) {
	return uc.repo.GetAddress(ctx, ki)
}

// GetBalance proxies the GetBalance call to the repository.
func (uc *AccountUsecase) GetBalance(ctx context.Context, denom TfDenom, address string) (string, error) {
	return uc.repo.GetBalance(ctx, denom, address)
}

// Send proxies the Send transaction call to the repository.
func (uc *AccountUsecase) Send(ctx context.Context, from KeyInfo, toAddress string, denom TfDenom, value string) (string, error) {
	return uc.repo.Send(ctx, from, toAddress, denom, value)
}

// GenKey proxies the GenKey call to the repository.
func (uc *AccountUsecase) GenKey(ctx context.Context, header Header, attrs KeyAttributes) (string, error) {
	return uc.repo.GenKey(ctx, header, attrs)
}

// GetPubKey proxies the GetPubKey call to the repository.
func (uc *AccountUsecase) GetPubKey(ctx context.Context, header Header, attrs KeyAttributes) ([]byte, error) {
	return uc.repo.GetPubKey(ctx, header, attrs)
}
