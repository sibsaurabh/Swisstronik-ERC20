//go:build wireinject
// +build wireinject

package main

import (
	"account/internal/biz"
	"account/internal/conf"
	"account/internal/data"
	"account/internal/server"
	"account/internal/service"

	blk "account/api/blkchn-svc/v1"
	blockchain "account/api/blockchain"
	kms "account/api/kms-svc/v1"

	"github.com/go-kratos/kratos/v2"
	"github.com/go-kratos/kratos/v2/log"

	// rpc "github.com/go-kratos/kratos/v2/transport/grpc"
	rpc "google.golang.org/grpc"

	"github.com/google/wire"
	"google.golang.org/grpc/credentials/insecure"
)

// NewBlockchainClient dials the downstream blockchain and returns its client and cleanup.
func NewBlockchainClient(c *conf.Server) (blockchain.BlockchainServiceClient, func(), error) {
	addr := c.Downstream.Blockchain
	log.Infof("Dialing blockchain at: %s", addr)
	conn, err := rpc.Dial(
		addr,
		rpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		return nil, nil, err
	}
	cleanup := func() { conn.Close() }
	return blockchain.NewBlockchainServiceClient(conn), cleanup, nil
}

// NewBlkClient dials the downstream blkchn-svc and returns its client and cleanup.
func NewBlkClient(c *conf.Server) (blk.BlkchnSvcClient, func(), error) {
	addr := c.Downstream.Blkchn
	log.Infof("Dialing blkchn-svc at: %s", addr)

	conn, err := rpc.Dial(
		addr,
		rpc.WithTransportCredentials(insecure.NewCredentials()),
	)

	if err != nil {
		log.Errorf("Failed to connect to blkchn-svc: %v", err)
		return nil, nil, err
	}

	cleanup := func() {
		log.Infof("Closing blkchn-svc connection")
		conn.Close()
	}
	return blk.NewBlkchnSvcClient(conn), cleanup, nil
}

// NewKmsClient dials the downstream kms-svc and returns its client and cleanup.
func NewKmsClient(c *conf.Server) (kms.KmsSvcClient, func(), error) {
	conn, err := rpc.Dial(
		c.Downstream.Kms,
		rpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		return nil, nil, err
	}
	cleanup := func() { conn.Close() }
	return kms.NewKmsSvcClient(conn), cleanup, nil
}

// wireApp initializes the Kratos application with all dependencies.
func wireApp(
	c *conf.Server,
	d *conf.Data,
	logger log.Logger,
) (*kratos.App, func(), error) {
	panic(wire.Build(
		NewBlockchainClient,
		NewBlkClient,
		NewKmsClient,
		data.ProviderSet,
		biz.ProviderSet,
		service.ProviderSet,
		server.ProviderSet,
		newApp,
	))
}
